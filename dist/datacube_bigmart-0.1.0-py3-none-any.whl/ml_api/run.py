from ml_api.api.app import create_app

application = create_app()
print (application)

if __name__ == '__main__':
    application.run()

