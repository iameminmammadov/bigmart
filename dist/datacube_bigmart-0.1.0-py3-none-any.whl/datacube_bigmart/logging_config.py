import logging
import sys


def logging_configuration():
    logger = logging.getLogger(__name__)
    format_logging = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(funcname)s:%(lineno)d - %(message)s')

    system_handler = logging.StreamHandler(sys.stdout)
    #system_handler.setLevel(logging.WARNING)
    system_handler.setFormatter(format_logging)
    logger.addHandler(system_handler)

    return logger
