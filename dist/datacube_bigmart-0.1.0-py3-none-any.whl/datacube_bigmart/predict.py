from datacube_bigmart.data_management import DataManagement
from datacube_bigmart import config
import pandas as pd

import logging

_logger = logging.getLogger(__name__)

def make_prediction(test_data):
    dm = DataManagement()
    X_test = dm.load_dataset(test_data)
    _pipe = dm.load_pipeline()
    y_pred = _pipe.predict(X_test)
    _logger.info(f"Predictions are made with model version: ")
    return y_pred

make_prediction(config.TESTING_DATA_FILE)
