import logging
import sys


def logging_configuration():
    _logger = logging.getLogger(__name__)
    format_logging = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(funcname)s:%(lineno)d - %(message)s')

    system_handler = logging.StreamHandler(sys.stdout)
    file_handler = logging.FileHandler('file.log')

    system_handler.setLevel(logging.WARNING)
    file_handler.setLevel(logging.ERROR)

    system_handler.setFormatter(format_logging)
    file_handler.setFormatter(format_logging)

    _logger.addHandler(system_handler)
    _logger.addHandler(file_handler)
    return _logger
