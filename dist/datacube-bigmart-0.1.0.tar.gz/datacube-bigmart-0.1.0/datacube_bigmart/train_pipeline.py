from sklearn.model_selection import train_test_split

from datacube_bigmart.pipeline import BigMartPipeline
from datacube_bigmart.data_management import DataManagement
from datacube_bigmart import config
from sklearn.metrics import mean_absolute_error as mae
from datacube_bigmart.version import __version__
from datacube_bigmart.logging_config import logging_configuration

from xgboost import XGBRegressor
from sklearn.ensemble import RandomForestRegressor
import logging

import warnings
warnings.filterwarnings("ignore")

_logger = logging_configuration()


def run_training():
    dm = DataManagement()
    data = dm.load_dataset(config.TRAINING_DATA_FILE)
    X = data.iloc[:, :-1]
    y = data['Item_Outlet_Sales']
    train_ratio = 0.70
    validation_ratio = 0.15
    test_ratio = 0.15

    X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                        test_size=1 - train_ratio,
                                                        random_state=42)

    X_val, X_test, y_val, y_test = train_test_split(X_test, y_test,
                                                    test_size=test_ratio / (test_ratio + validation_ratio),
                                                    random_state=42)
    bmp = BigMartPipeline()
    dm = DataManagement()

    #search_space = [{
    #    'clf': [RandomForestRegressor()],
    #}]

    #pipeline = bmp.pipeline(search_space)
    #pipe = pipeline.fit(X_train, y_train)

    pipe = dm.load_pipeline()

    y_pred = pipe.predict(X_test)
    print('MAE: ', mae(y_test, y_pred))


    _logger.info(f'saving model version: {__version__}')

    #dm.save_pipeline(pipeline)



if __name__ == '__main__':
    run_training()
