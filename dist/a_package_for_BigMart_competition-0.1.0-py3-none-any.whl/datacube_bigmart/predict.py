from datacube_bigmart.data_management import DataManagement
from datacube_bigmart import config
import version

import logging

_logger = logging.getLogger(__name__)

def make_prediction(test_data):
    dm = DataManagement()
    _pipe = dm.load_pipeline()
    X_test = config.TESTING_DATA_FILE.copy()
    y_pred = _pipe.predict(X_test)
    #_logger.info(f"Predictions are made with model version: ",
    #             f"Inputs": {X_test},
    #             f"Predictions": {y_pred})
    return y_pred

