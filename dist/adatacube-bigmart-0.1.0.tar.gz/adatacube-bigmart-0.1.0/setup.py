import io 
import os
import setuptools

def list_reqs(fname='requirements.txt'):
    with open(fname) as fd:
        return fd.read().splitlines()


setuptools.setup(name='adatacube-bigmart',
                 version='0.1.0',
                 author='Emin Mammadov',
                 author_email='emin.e.mammadov@protonmail.com',
                 url='https://github.com/iameminmammadov/BigMart',
                 packages=setuptools.find_packages(),
                 install_requires=list_reqs(),
                 extras_require={},
                 license='BSD 3',
                 classifiers=[
                     "Programming Language :: Python :: 3",
                     "License :: OSI Approved :: MIT License",
                     "Operating System :: OS Independent",
                 ],
                 python_requires='>=3.6.0'
                 )

