import pandas as pd
from datacube_bigmart import config
import os
from os.path import join, exists
import joblib

import logging

_logger = logging.getLogger(__name__)

class DataManagement():
    def __init__(self, save_file_name=None):
        self.save_file_name = save_file_name

    def load_dataset(self, *datasets):
        """Loads dataset.
        :param *args: passed datasets (could train, test or both)
        :return _data_train DataFrame: returns loaded train data set
        :return _data_test DataFrame: returns loaded test data set
        """

        if len(datasets) == 0:
            raise ValueError('Please provide either training, or testing, or both data sets')
        elif len(datasets) == 1:
            if 'Train' in datasets[0]:
                _data_train = pd.read_csv(f"{config.DATASET_DIR}/{datasets[0]}")
                print ('Passed file is a Training set')
                return _data_train
            else:
                _data_test = pd.read_csv(f"{config.DATASET_DIR}/{datasets[0]}")
                print ('Passed file is a Testing set')
                return _data_test
        elif len(datasets) == 2:
            _data_train = pd.read_csv(f"{config.DATASET_DIR}/{datasets[0]}")
            _data_test = pd.read_csv(f"{config.DATASET_DIR}/{datasets[1]}")
            return _data_train, _data_test

    def save_pipeline(self, pipeline_to_persist):
        """
        Save the pipeline. Saved pipeline overwrites any previous saved models. By doing so, in the published
        version, there is only one trained model and it's easy to trace it
        :param sklearn object pipeline_to_persist: Passed a built Pipeline, imported from sklearn
        :return: N/A
        """

        self.save_file_name = f"{config.PIPELINE_SAVE_FILE}{_version},pkl" #need to fix version in setup.py
        save_path = join(config.TRAINED_MODEL_DIR, self.save_file_name)
        if exists(save_path):
            os.remove(save_path)
        joblib.dump(pipeline_to_persist, save_path)
        _logger.info(f"saved pipeline: {self.save_file_name}")

    def load_pipeline(self):
        """
        Loads the pipeline for further usage
        :param : N/A
        :return pipeline: Returns a pipeline that is a sklearn object
        """
        file_path = join(config.TRAINED_MODEL_DIR, self.save_file_name)
        pipeline = joblib.load(file_path)
        return pipeline





if __name__ == "__main__":
    from data_management import DataManagement
    dm = DataManagement()
    data_train, data_test = dm.load_dataset('Train.csv', 'Test.csv')
    print (data_train.shape)
    print (data_test.shape)




